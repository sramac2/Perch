package com.example.android.perch;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SampleLogin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sample_login);
    }
}
